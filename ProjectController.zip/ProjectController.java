package pkg;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import dao.customer.CustomerInfo;
import dao.product.ProductInfo;
import dao.product.ProductJdbcTemplate;

@Controller
public class ProjectController {

	ProductJdbcTemplate objtemplate = new ProductJdbcTemplate();

	@RequestMapping("/home")
	public String mainPage() {

		return "homePage";
	}

	@RequestMapping("/showAllProducts")
	public String showAllCustomerDetails(Model model) {
		List<ProductInfo> list = objtemplate.getAllProducts();

		model.addAttribute("allproducts", list);
		model.addAttribute("tc", list.size());

		return "viewProducts";
	}
	
	@RequestMapping("/user-dashboard")
	public String showAllProduct(Model model) {
	
		List<ProductInfo> list = objtemplate.getAllProducts();

		model.addAttribute("allproducts", list);
		model.addAttribute("tc", list.size());
		return "user-dashboard";
	}
	
	@RequestMapping("Prod")
	public String showAllProducts(Model model) {
		List<ProductInfo> list = objtemplate.getAllProducts();

		model.addAttribute("allproducts", list);
		model.addAttribute("tc", list.size());
		return "Prod";
	}
	
	@RequestMapping("ProductHori")
	public String showAllProductHorizontally(Model model) {
		
		List<ProductInfo> list = objtemplate.getAllProducts();

		model.addAttribute("allproducts", list);
		model.addAttribute("tc", list.size());
	
		return "ProductHori";
	}
	
	@RequestMapping("/viewFilterProduct")
	public String showFilterPoduct(HttpServletRequest request, Model model)
	{
		String[] categoryname  = request.getParameterValues("cat");
		//String categoryname  = request.getParameter("cat");
		if (categoryname != null  ) {
		List<ProductInfo> list = objtemplate.getAllProducts(categoryname);
		//List<ProductInfo> list=null;
		model.addAttribute("allproducts",list);
		} 
		return "ProductHori";
		}
}